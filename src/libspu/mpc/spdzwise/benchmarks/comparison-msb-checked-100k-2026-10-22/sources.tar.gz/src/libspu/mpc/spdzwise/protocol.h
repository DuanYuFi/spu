// Copyright 2026 The SPU Authors. All Rights Reserved.
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#pragma once

#include "libspu/core/context.h"

namespace spu::mpc::spdzwise {

// Dispatches by spdzwise_config.domain. FIELD uses p = 2^61 - 1; RING uses
// internal Z/(2^128) and external Z/(2^64). Both require FM64.
// This arithmetic/ABFL integration harness is not a complete PPML protocol and
// remains unreachable through Factory::RegisterProtocol until acceptance.
void registerArithmeticPrototype(
    SPUContext* ctx, const std::shared_ptr<yacl::link::Context>& link);

void registerFieldArithmeticPrototype(
    SPUContext* ctx, const std::shared_ptr<yacl::link::Context>& link);

void registerRingArithmeticPrototype(
    SPUContext* ctx, const std::shared_ptr<yacl::link::Context>& link);

}  // namespace spu::mpc::spdzwise
